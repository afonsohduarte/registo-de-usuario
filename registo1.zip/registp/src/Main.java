import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nSistema de Registo de Usuário");
            System.out.println("1. Cadastrar novo usuário");
            System.out.println("2. Listar usuários");
            System.out.println("3. Editar usuário");
            System.out.println("4. Excluir usuário");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");

            int option;
            try {
                option = scanner.nextInt();
                scanner.nextLine();
            } catch (Exception e) {
                System.out.println("Opção inválida. Por favor, insira um número de 1 a 5.");
                scanner.nextLine();
                continue;
            }

            switch (option) {
                case 1:
                    System.out.print("Nome: ");
                    String name = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Senha: ");
                    String password = scanner.nextLine();
                    userService.addUser(name, email, password);
                    break;

                case 2:
                    userService.listUsers();
                    break;

                case 3:
                    System.out.print("Email do usuário para editar: ");
                    String editEmail = scanner.nextLine();
                    System.out.print("Novo nome: ");
                    String newName = scanner.nextLine();
                    System.out.print("Nova senha: ");
                    String newPassword = scanner.nextLine();
                    userService.editUser(editEmail, newName, newPassword);
                    break;

                case 4:
                    System.out.print("Email do usuário para excluir: ");
                    String deleteEmail = scanner.nextLine();
                    userService.deleteUser(deleteEmail);
                    break;

                case 5:
                    System.out.println("Encerrando o sistema.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
}