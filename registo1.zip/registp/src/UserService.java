import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserService {
    private List<User> users;

    public UserService() {
        this.users = new ArrayList<>();
    }

    public void addUser(String name, String email, String password) {
        if (isValidEmail(email)) {
            User user = new User(name, email, password);
            users.add(user);
            System.out.println("Usuário adicionado: " + user);
        } else {
            System.out.println("Erro: O e-mail deve seguir o formato válido: 'nome@numeros.numeros'.");
        }
    }

    public void listUsers() {
        if (users.isEmpty()) {
            System.out.println("Nenhum usuário cadastrado.");
        } else {
            users.forEach(user -> System.out.println(user));
        }
    }

    public void editUser(String email, String newName, String newPassword) {
        if (isValidEmail(email)) {
            Optional<User> userOptional = findUserByEmail(email);
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                user.setName(newName);
                user.setPassword(newPassword);
                System.out.println("Usuário atualizado: " + user);
            } else {
                System.out.println("Usuário com email " + email + " não encontrado.");
            }
        } else {
            System.out.println("Erro: O e-mail deve seguir o formato válido: 'nome@numeros.numeros'.");
        }
    }

    public void deleteUser(String email) {
        if (isValidEmail(email)) {
            Optional<User> userOptional = findUserByEmail(email);
            if (userOptional.isPresent()) {
                users.remove(userOptional.get());
                System.out.println("Usuário removido com sucesso.");
            } else {
                System.out.println("Usuário com email " + email + " não encontrado.");
            }
        } else {
            System.out.println("Erro: O e-mail deve seguir o formato válido: 'nome@numeros.numeros'.");
        }
    }

    private boolean isValidEmail(String email) {
        String regex = "^[a-zA-Z0-9._%+-]+@[0-9]+\\.[0-9]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private Optional<User> findUserByEmail(String email) {
        return users.stream().filter(user -> user.getEmail().equals(email)).findFirst();
    }
}
